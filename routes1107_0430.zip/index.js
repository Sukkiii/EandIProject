const express = require('express');
const permission = require('../middlewares/permission')
const usersRouter = require('../routes/users');
const productsRouter = require('../routes/products');
const ordersRouter = require('../routes/orders');
const { getProduct, getProductList, getProduct } = require('../services/productServices');
const router = express.Router();

// 로그인&아웃, 회원 가입
router.post('/signup', signup) // 회원가입
router.post('/login', login) // 로그인
router.delete('/logout', logout) // 로그아웃

//메인 페이지 및 상품 조회
router.get('/', getCategory) // 주문 조회
router.get('/', getProductList) // 상품 목록 조회
router.get('/', getProduct) // 상품 조회

// 경로에 따른 최소 권한 설정
router.get('/admin', permission('admin'), (req, res) => { res.redirect('/admin'); })
router.get('/seller', permission('seller'), (req, res) => { res.redirect('/seller'); })
router.get('/user', permission('user'), (req, res) => { res.redirect('/user'); })


router.get('/admin', usersRouter)
router.get('/admin', productsRouter)
router.get('/admin', ordersRouter)

router.get('/seller', usersRouter)
router.get('/seller', productsRouter)
router.get('/seller', ordersRouter)

router.get('/user', usersRouter)
router.get('/user', productsRouter)
router.get('/user', ordersRouter)


module.exports = router;