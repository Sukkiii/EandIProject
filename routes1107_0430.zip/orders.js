const express = require('express');
const { getOrder, createOrder, updateOrder, deleteOrder, finishOrder } = require('../services/orderServices')
const router = express.Router();

// 주문은 app.js에서 미리 유저 체크
router.get('/orders', getOrder) // 주문 조회
router.post('/orders/:id', createOrder) // 주문 추가
router.put('/orders/:id', updateOrder) // 주문 수정
router.put('/orders', finishOrder) // 주문 완료
router.delete('/orders/:id', deleteOrder) // 주문 삭제

module.exports = router;