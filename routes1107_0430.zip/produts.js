const express = require('express');
const { createCategory, updateCategory, deleteCategory, createProduct, getProduct, getProductList, getProductDetail, deleteProduct } = require('../services/productServices');
const router = express.Router();

router.get('/', getCategory) // 카테고리 조회
router.get('/', getProduct) // 상품 조회
router.get('/', getProductList) // 상품 목록 조회
router.get('/', getProductDetail) // 상품 상세 조회

router.post('/products/:id', createProduct) // 상품 추가
router.put('/products/:id', updateProduct) // 상품 수정
router.delete('/products/:id', deleteProduct) // 상품 삭제

router.post('/products/:id', createCategory) // 카테고리 추가
router.put('/products/:id', updateCategory) // 카테고리 수정
router.delete('/products/:id', deleteCategory) // 카테고리 삭제

module.exports = router;