const express = require('express');
const { getUserList, updateUser, deleteUser, getUser } = require('../services/userServices')
const router = express.Router();

router.put('/users/:id', updateUser) // 회원 정보 수정
router.delete('/users/:id', deleteUser) // 회원 삭제(탈퇴)
router.get('/users/:id', getUser) // 회원 정보 조회

router.get('/users', getUserList) // 회원 목록 조회

module.exports = router;