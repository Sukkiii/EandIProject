const asyncHandler = require('express-async-handler')
const { User } = require('../models/model');

module.exports = { authUser, createUser };